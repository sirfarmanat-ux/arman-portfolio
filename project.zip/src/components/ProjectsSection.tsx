import React, { useState } from 'react';
import { ExternalLink, Play } from 'lucide-react';
import armanimage from "../images/brand.jpg";
import natureimage from "../images/nature.jpg";
import companyimage from "../images/company.png";
import mustang from "../images/Mustang.png";
import drawing from "../images/drawing.jpg";
import typography from "../images/typography.png";
import instagram2 from "../images/instagram2.jpg";
import quotedesign from "../images/typography2.png";
import fashion from "../images/fashions.png";

const ProjectsSection = () => {
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = [
    { id: 'all', label: 'All Projects' },
    { id: 'graphic', label: 'Graphic Design' },
    { id: 'typography', label: 'Typography & Stories' },
    { id: 'photography', label: 'Edited Photos' },
    { id: 'video', label: 'Edited Videos' }
  ];

  const projects = [
    // Graphic Design Projects
    {
      id: 1,
      category: 'graphic',
      title: 'Brand Identity Design',
      image: companyimage,
      type: 'image'
    },
    {
      id: 2,
      category: 'Can draw anything',
      title: 'Sketch',
      image: drawing,
      type: 'image'
    },
    {
      id: 3,
      category: 'graphic',
      title: 'Business Cards',
      image: mustang,
      type: 'image'
    },
    
    // Typography & Instagram Stories
    {
      id: 4,
      category: 'typography',
      title: 'Instagram Story Template',
      image: instagram2,
      type: 'story'
    },
    {
      id: 5,
      category: 'typography',
      title: 'Typography Poster',
      image: typography,
      type: 'story'
    },
    {
      id: 6,
      category: 'typography',
      title: 'Quote Design',
      image: quotedesign,
      type: 'story'
    },

    // Edited Photos
    {
      id: 7,
      category: 'photography',
      title: 'Portrait Retouch',
      image: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=400',
      type: 'image'
    },
    {
      id: 8,
      category: 'photography',
      title: 'Landscape Enhancement',
      image: natureimage,
      type: 'image'
    },
    {
      id: 9,
      category: 'photography',
      title: 'Product Photography',
      image: 'https://images.pexels.com/photos/279906/pexels-photo-279906.jpeg?auto=compress&cs=tinysrgb&w=400',
      type: 'image'
    },
    {
      id: 10,
      category: 'photography',
      title: 'Fashion Edit',
      image: fashion
      ,
      type: 'image'
    },
    {
      id: 11,
      category: 'photography',
      title: 'Street Photography',
      image: 'https://i.pinimg.com/1200x/e9/3d/4e/e93d4e0471fb23a9529e4bb58cbda6c6.jpg',
      type: 'image'
    },
    {
      id: 12,
      category: 'photography',
      title: 'Nature Edit',
      image: 'https://images.pexels.com/photos/1252814/pexels-photo-1252814.jpeg?auto=compress&cs=tinysrgb&w=400',
      type: 'image'
    },
    {
      id: 13,
      category: 'video',
      title: 'Video Editing',
      image: 'https://images.pexels.com/photos/3944091/pexels-photo-3944091.jpeg?auto=compress&cs=tinysrgb&w=400',
      type: 'video'
    },
  ];

  const filteredProjects = activeCategory === 'all' 
    ? projects 
    : projects.filter(project => project.category === activeCategory);

  return (
    <section id="projects" className="py-20 bg-gradient-to-b from-stone-50 to-amber-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-black text-black mb-4">
            MY PROJECTS
          </h2>
          <p className="text-2xl font-serif italic text-rose-800">
            Creative Portfolio
          </p>
          <div className="w-24 h-1 bg-rose-800 mx-auto mt-4"></div>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-6 py-3 rounded-full font-medium transition-all duration-300 ${
                activeCategory === category.id
                  ? 'bg-rose-800 text-white shadow-lg'
                  : 'bg-white text-gray-700 hover:bg-rose-100 hover:text-rose-800 shadow-md'
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <div
              key={project.id}
              className="group relative bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-500 hover:-translate-y-2"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="relative overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className={`w-full object-cover transition-transform duration-500 group-hover:scale-110 ${
                    project.type === 'story' ? 'h-60' : 'h-60'
                  }`}
                />
                
                {/* Overlay */}
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-300 flex items-center justify-center">
                  <div className="transform translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                    {project.type === 'video' ? (
                      <Play size={50} className="text-white" />
                    ) : (
                      <ExternalLink size={48} className="text-white" />
                    )}
                  </div>
                </div>
              </div>

              {/* Project Info */}
              <div className="p-6">
                <h3 className="text-lg font-semibold text-black mb-2 group-hover:text-rose-800 transition-colors">
                  {project.title}
                </h3>
                <p className="text-sm text-gray-600 capitalize">
                  {categories.find(cat => cat.id === project.category)?.label || project.category}
                </p>
              </div>

              {/* Corner decoration */}
              <div className="absolute top-4 right-4 w-6 h-6 opacity-0 group-hover:opacity-30 transition-opacity">
                <svg viewBox="0 0 20 20" className="w-full h-full">
                  <path d="M5,5 L15,15 M15,5 L5,15" stroke="#8B1538" strokeWidth="2" />
                </svg>
              </div>
            </div>
          ))}
        </div>

        {/* Load More Button */}
        <div className="text-center mt-12">
          <button className="px-8 py-3 bg-white text-rose-800 border-2 border-rose-800 rounded-full font-medium hover:bg-rose-800 hover:text-white transition-all duration-300 shadow-lg hover:shadow-xl">
            View More Projects
          </button>
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;