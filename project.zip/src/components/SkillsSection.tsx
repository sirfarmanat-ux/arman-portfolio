import React from 'react';
import { Palette, Layers, Video, Edit3, Camera, Scissors, Layers2Icon } from 'lucide-react';

const SkillsSection = () => {
  const skills = [
    {
      name: 'Sketch',
      icon: Palette,
      description: 'Can draw anything'
    },
    {
      name: 'Frontend Development',
      icon: Layers,
      description: 'Vector graphics and UI design'
    },
    {
      name: 'Canva',
      icon: Edit3,
      description: 'Quick designs and social media graphics'
    },
    {
      name: 'Premiere Pro',
      icon: Video,
      description: 'Professional video editing'
    },
    {
      name: 'Video Editing',
      icon: Scissors,
      description: 'Motion graphics and effects'
    },
    {
      name: 'Photography',
      icon: Camera,
      description: 'Portrait and product photography'
    }
  ];

  return (
    <section id="skills" className="py-20 bg-amber-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-black text-black mb-2">
            MY SKILLS
          </h2>
          <p className="text-2xl font-serif italic text-rose-800">
            Creative Skills
          </p>
          <div className="w-24 h-1 bg-rose-800 mx-auto mt-4"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skills.map((skill, index) => {
            const IconComponent = skill.icon;
            return (
              <div
                key={skill.name}
                className="group bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border border-amber-100"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-rose-100 rounded-2xl mb-6 group-hover:bg-rose-200 transition-colors">
                    <IconComponent size={32} className="text-rose-800" />
                  </div>
                  
                  <h3 className="text-xl font-bold text-black mb-3">
                    {skill.name}
                  </h3>
                  
                  <p className="text-gray-600 leading-relaxed">
                    {skill.description}
                  </p>
                </div>

                {/* Decorative corner */}
                <div className="absolute top-4 right-4 w-6 h-6 opacity-20 group-hover:opacity-40 transition-opacity">
                  <svg viewBox="0 0 20 20" className="w-full h-full">
                    <circle cx="10" cy="10" r="2" fill="#8B1538" />
                    <circle cx="4" cy="4" r="1" fill="#8B1538" />
                    <circle cx="16" cy="4" r="1" fill="#8B1538" />
                    <circle cx="4" cy="16" r="1" fill="#8B1538" />
                    <circle cx="16" cy="16" r="1" fill="#8B1538" />
                  </svg>
                </div>
              </div>
            );
          })}
        </div>

        {/* Decorative brush stroke */}
        <div className="flex justify-center mt-16">
          <div className="w-48 h-8 opacity-30">
            <svg viewBox="0 0 200 40" className="w-full h-full">
              <path
                d="M10,20 Q50,5 100,20 Q150,35 190,20"
                stroke="#8B1538"
                strokeWidth="4"
                fill="none"
                className="animate-pulse"
              />
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SkillsSection;